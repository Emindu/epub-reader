Read — frontend files for redesign
===================================

This zip has no build tooling, dependencies, or backend code — just the
three files that define how the app looks, for both variants of the app.
Hand this to a designer/front-end dev working on visuals; they don't need
the rest of the repo to understand or restyle the UI.

Each variant folder has the same three files, each with a different job:

  index.html     All markup: the library screen, the reader screen, and
                 every modal/drawer/popover (table of contents, settings,
                 voice setup, chat, vocabulary review, etc).

  src/styles.css The entire design system: color tokens for all 16 themes
                 (look for `:root` and `[data-theme="..."]` blocks), light/
                 dark mode, typography scale, spacing, component styles.
                 This is almost certainly the main file a redesign touches.

  src/main.ts    Application logic — not styling, but it decides what gets
                 shown, hidden, or rendered into the HTML above (opening/
                 closing drawers, switching themes, building book cards,
                 positioning popovers). Useful context for understanding
                 WHY an element looks the way it does, but a visual redesign
                 will mostly live in styles.css and index.html.

Folders:

  desktop/   The original Tauri desktop app's frontend.
  web/       The browser version's frontend — same design, ported to run
             standalone in a browser. Functionally the two are nearly
             identical; start here if you only want to preview changes,
             since it just needs a browser (no desktop build step).
  screenshots/  Reference images of every major screen, so a redesigner can
                see the current look of each one without running the app.

Fonts (loaded from Google Fonts in index.html's <head>):
  Newsreader, Literata, Lora, Bitter, Inter, Atkinson Hyperlegible,
  JetBrains Mono.

None of this includes node_modules, the Rust/Tauri backend, or the web
app's server — only what shapes the interface.
